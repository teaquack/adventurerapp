using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using NLog.Extensions.Logging;
using NLog.Web;
using AdventurerApi.Services;
using AdventurerApi.Entities;
using Microsoft.EntityFrameworkCore;

namespace AdventurerApi
{
    public class Startup
    {
        public static IConfigurationRoot Configuration;
        public Startup(IHostingEnvironment environment)
        {
            environment.ConfigureNLog("nlog.config");
            var builder = new ConfigurationBuilder()
                .SetBasePath(environment.ContentRootPath)
                .AddJsonFile("appSettings.json", optional:false, reloadOnChange:true)
                .AddJsonFile($"appSettings.{environment.EnvironmentName}.json", optional:true, reloadOnChange:true);
                // .AddEnvironmentVariables(); //may not be needed for netcore 2.0

            Configuration = builder.Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAnything",
                    builder => builder.AllowAnyHeader()
                                    .AllowAnyMethod()
                                    .AllowAnyOrigin());
                    //WithOrigins("http://localhost:5000"));
            });
            services.Configure<IISOptions>(options =>
            {
                
            });
            services.AddMvc();
            services.AddLogging(builder => builder
                .AddConsole()
                .AddDebug()
                .AddProvider(new NLog.Extensions.Logging.NLogLoggerProvider())
                // .AddFilter("System", LogLevel.Information) // Rule for all providers
                // .AddFilter<DebugLoggerProvider>("Microsoft", LogLevel.Trace) // Rule only for debug provider
                // .AddConfiguration(configuration.GetSection("Logging"))
                );
            
            // var connectionString = @"Server=(localdb)\mssqllocaldb;Database=AdventurerApi;Trusted_Connection=True;";
            var connectionString = Startup.Configuration["connectionStrings:DefaultConnection"];
            services.AddDbContext<AdventurerContext>(o => o.UseSqlServer(connectionString));
            #if DEBUG
            services.AddTransient<IMailService, LocalMailService>();
            #else
            services.AddTransient<IMailService, CloudMailService>();
            #endif

            services.AddScoped<IAdventurerRepository, AdventurerRepository>();
            services.AddScoped<TestService>();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory,
            AdventurerContext adventurerContext)
        {
            // loggerFactory.AddConsole();
            // loggerFactory.AddDebug();
            loggerFactory.AddNLog();
            app.AddNLogWeb();

            //seed
            adventurerContext.EnsureSeedDataForContext();

            //cors = cross origin resource sharing
            app.UseCors("AllowAnything");

            if (env.IsDevelopment()) 
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler();
            }

            app.UseStatusCodePages();

            AutoMapper.Mapper.Initialize(config =>
            {
                config.CreateMap<Entities.Note, Models.NoteWithoutSubnotesDto>();
                config.CreateMap<Entities.Note, Models.NoteDto>();
                config.CreateMap<Entities.Subnote, Models.SubnoteDto>();
                config.CreateMap<Models.SubnoteForCreationDto, Entities.Subnote>();
                config.CreateMap<Models.SubnoteForUpdateDto, Entities.Subnote>();
                config.CreateMap<Entities.Subnote, Models.SubnoteForUpdateDto>();
            });

            // app.Run(async (context) =>
            // {
            //     await context.Response.WriteAsync("environment is " + env.EnvironmentName);
            // });

            app.UseMvcWithDefaultRoute();

            // app.Run((context) =>
            // {
            //     throw new Exception("test exception");
            // });
        }
    }
}