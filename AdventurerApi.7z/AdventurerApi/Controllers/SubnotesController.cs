using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using AdventurerApi.Models;
using System;
using System.Linq;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.Extensions.Logging;
using AdventurerApi.Services;
using AutoMapper;
using Microsoft.AspNetCore.Cors;

namespace AdventurerApi.Controllers
{
    // [Route("api/[controller]")]
    [Route("api/notes")]
    [EnableCors("AllowAnything")]
    public class SubnotesController : Controller
    {
        private ILogger<SubnotesController> _logger;
        private IMailService _mailService;
        private IAdventurerRepository _adventurerRepository;

        public SubnotesController(ILogger<SubnotesController> logger,
            IMailService mailService,
            IAdventurerRepository adventurerRepository)
        {
            _logger = logger;
            _mailService = mailService;
            _adventurerRepository = adventurerRepository;
        }

        [HttpGet("{noteId}/subnotes")]
        public IActionResult GetSubnotes(int noteId)
        {
            try
            {
                // var note = NotesDataStore.Current.Notes.FirstOrDefault(n => n.Id == noteId);
                var noteExists = _adventurerRepository.NoteExists(noteId);
                if (!noteExists) {                    
                    _logger.LogInformation(message: $"Note with id {noteId} wasn't found when accessing subnotes.");
                    return NotFound();
                }

                var subnotesForNote = _adventurerRepository.GetSubnotesForNote(noteId);

                var subnotesResults = Mapper.Map<IEnumerable<SubnoteDto>>(subnotesForNote);
                return Ok(subnotesResults);
            }
            catch (Exception ex)
            {
                _logger.LogCritical($"Exception while getting subnotes for note with id {noteId}.", ex);
                return StatusCode(500, "Error occurred.");
            }
        }

        [HttpGet("{noteId}/subnote/{id}", Name = "GetSubnote")]
        public IActionResult GetSubnote(int noteId, int id)
        {
            var noteExists = _adventurerRepository.NoteExists(noteId);
            if (!noteExists) {                    
                _logger.LogInformation(message: $"Note with id {noteId} wasn't found when accessing subnotes.");
                return NotFound();
            }

            var subnote = _adventurerRepository.GetSubnoteForNote(noteId, id);
            if (subnote == null) {
                return NotFound();
            }

            var subnoteResult = Mapper.Map<SubnoteDto>(subnote);
            return Ok(subnoteResult);
        }

        [HttpPost("{noteId}/subnote")]
        public IActionResult CreateSubnote(int noteId,
            [FromBody] SubnoteForCreationDto subnote)
        {
            if (subnote == null)
            {
                return BadRequest();
            }

            if (subnote.Body == subnote.Subject)
            {
                ModelState.AddModelError("Body", "The provided body of subnote should be different from its subject.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // var note = NotesDataStore.Current.Notes.FirstOrDefault(n => n.Id == noteId);
            var noteExists = _adventurerRepository.NoteExists(noteId);
            if (!noteExists) {
                return NotFound();
            }

            var finalSubnote = Mapper.Map<Entities.Subnote>(subnote);
            _adventurerRepository.AddSubnoteForNote(noteId, finalSubnote);

            var saveSuccess = _adventurerRepository.Save();
            if (!saveSuccess) {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            var createdSubnote = Mapper.Map<Models.SubnoteDto>(finalSubnote);

            return CreatedAtRoute("GetSubnote", new 
            {noteId = noteId, id = createdSubnote.Id}, createdSubnote);
        }

        [HttpPut("{noteId}/subnote/{id}")]
        public IActionResult UpdateSubnote(int noteId, int id,
            [FromBody] SubnoteForUpdateDto subnote)
        {
            if (subnote == null)
            {
                return BadRequest();
            }

            if (subnote.Body == subnote.Subject)
            {
                ModelState.AddModelError("Body", "The provided body of subnote should be different from its subject.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var noteExists = _adventurerRepository.NoteExists(noteId);
            if (!noteExists) {
                return NotFound();
            }

            var subnoteEntity = _adventurerRepository.GetSubnoteForNote(noteId, id);
            if (subnoteEntity == null) {
                return NotFound();
            }
            Mapper.Map(subnote, subnoteEntity);

            var saveSuccess = _adventurerRepository.Save();
            if (!saveSuccess) {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            return NoContent();
        }

        [HttpPatch("{noteId}/subnote/{id}")]
        public IActionResult PartiallyUpdateSubnote(int noteId, int id,
            [FromBody] JsonPatchDocument<SubnoteForUpdateDto> patchDocument)
        {
            if (patchDocument == null)
            {
                return BadRequest();
            }
            
            var noteExists = _adventurerRepository.NoteExists(noteId);
            if (!noteExists) {
                return NotFound();
            }

            var subnoteEntity = _adventurerRepository.GetSubnoteForNote(noteId, id);
            if (subnoteEntity == null)
            {
                return NotFound();
            }
            var subnoteToPatch = Mapper.Map<SubnoteForUpdateDto>(subnoteEntity);

            patchDocument.ApplyTo(subnoteToPatch, ModelState);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (subnoteToPatch.Body == subnoteToPatch.Subject)
            {
                ModelState.AddModelError("Body", "Provided body should be different from its subject.");
            }

            TryValidateModel(subnoteToPatch);
            
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            Mapper.Map(subnoteToPatch, subnoteEntity);

            if (!_adventurerRepository.Save()) {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            return NoContent();
        }

        [HttpDelete("{noteId}/subnote/{id}")]
        public IActionResult DeleteSubnote(int noteId, int id)
        {
            // var note = NotesDataStore.Current.Notes.FirstOrDefault(n => n.Id == noteId);            
            var noteExists = _adventurerRepository.NoteExists(noteId);
            if (!noteExists) {
                return NotFound();
            }
            
            var subnoteEntity = _adventurerRepository.GetSubnoteForNote(noteId, id);
            if (subnoteEntity == null)
            {
                return NotFound();
            }

            _adventurerRepository.DeleteSubnote(subnoteEntity);
            
            if (!_adventurerRepository.Save()) {
                return StatusCode(500, "A problem happened while handling your request.");
            }

            _mailService.Send("Subnote deleted.",
                    $"Subnote {subnoteEntity.Subject} with id {subnoteEntity.Id} was deleted.");

            return NoContent();
        }
    }
}