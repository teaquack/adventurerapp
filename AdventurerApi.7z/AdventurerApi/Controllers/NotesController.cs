using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using AdventurerApi.Models;
using System;
using System.Linq;
using AdventurerApi.Services;
using AutoMapper;
using Microsoft.AspNetCore.Cors;

namespace AdventurerApi.Controllers
{
    // [Route("api/[controller]")]
    [Route("api/notes")]
    [EnableCors("AllowAnything")]
    public class NotesController : Controller
    {
        private IAdventurerRepository _adventurerRepository;
        public NotesController(IAdventurerRepository adventurerRepository)
        {
            _adventurerRepository = adventurerRepository;
        }

        [HttpGet]
        public IActionResult GetNotes()
        {
            var noteEntities = _adventurerRepository.GetNotes();
            var results = Mapper.Map<IEnumerable<NoteWithoutSubnotesDto>>(noteEntities);
            
            return Ok(results);
        }

        [HttpGet("{id}")]
        public IActionResult GetNote(int id, bool includeSubnotes = false)
        {
            var noteEntity = _adventurerRepository.GetNote(id, includeSubnotes);
            if (noteEntity == null)
            {
                return NotFound();
            }

            if (includeSubnotes)
            {
                var noteResult = Mapper.Map<NoteDto>(noteEntity);
                return Ok(noteResult);
            } else {
                var noteWithoutSubnotesResult = Mapper.Map<NoteWithoutSubnotesDto>(noteEntity);
                return Ok(noteWithoutSubnotesResult);
            }

        }

        // [HttpGet("{id}", Name = "GetNote")]
        // public IActionResult GetById(string id)
        // {
        //     var item = _repo.Find(Int32.Parse(id));
        //     if (item == null)
        //     {
        //         return NotFound();
        //     }
        //     return new ObjectResult(item);
        // }

        // [HttpPost]
        // public IActionResult Create([FromBody] Note item)
        // {
        //     if (item == null)
        //     {
        //         return BadRequest();
        //     }
        //     _repo.Add(item);
        //     return CreatedAtRoute("GetNote", new { controller = "Note", id = item.Id }, item);
        // }

        // [HttpPatch]
        // public IActionResult Edit([FromBody] Note item)
        // {
        //     if (item == null)
        //     {
        //         return BadRequest();
        //     }
        //     _repo.Add(item);
        //     return new ObjectResult(item);
        // }

        // [HttpDelete("{id}")]
        // public void Delete(int id)
        // {
        //     _repo.Remove(id);
        // }
    }
}