using System;
using System.Linq;
using System.Reflection;
using AdventurerApi.Entities;
using AdventurerApi.Services;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace AdventurerApi.Controllers
{    
    [EnableCors("AllowAnything")]
    public class DummyController : Controller
    {
        private AdventurerContext _context;
        private TestService _testService;

        public DummyController(AdventurerContext context, TestService testService)
        {
            _context = context;
            _testService = testService;
        }

        [HttpGet]
        [Route("api/testdatabase")]
        public IActionResult TestDatabase()
        {
            try {
                _testService.TestThings();
                return Ok();
            } catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }
    }
}