
using System.Collections.Generic;
using AdventurerApi.Services;
using AutoMapper;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace AdventurerApi.Controllers
{
    [Route("api/character")]
    [EnableCors("AllowAnything")]
    public class CharacterController : Controller
    {
        private IAdventurerRepository _adventurerRepository;
        public CharacterController(IAdventurerRepository adventurerRepository)
        {
            _adventurerRepository = adventurerRepository;
        }
        
        // [HttpGet]
        // public IActionResult GetCharacters()
        // {
            // var charEntities = _adventurerRepository.GetCharacters();
            // var results = Mapper.Map<IEnumerable<CharacterDto>>(charEntities);
            // return Ok(results);
        // }
    }
}