using System.Collections.Generic;
using System.Linq;
using AdventurerApi.Entities;
using Microsoft.EntityFrameworkCore;

namespace AdventurerApi.Services
{
    public class AdventurerRepository : IAdventurerRepository
    {
        private AdventurerContext _context;
        public AdventurerRepository(AdventurerContext context)
        {
            _context = context;
        }

        public bool NoteExists(int noteId)
        {
            return _context.Notes.Any(n => n.Id == noteId);
        }

        public IEnumerable<Note> GetNotes()
        {
            return _context.Notes.OrderBy(n => n.Subject).ToList();
        }

        public Note GetNote(int noteId, bool includeSubnotes)
        {
            if (includeSubnotes)
            {
                return _context.Notes.Include(n => n.Subnotes)
                        .Where(n => n.Id == noteId).FirstOrDefault();
            }

            return _context.Notes.Where(n => n.Id == noteId).FirstOrDefault();
        }

        public Subnote GetSubnoteForNote(int noteId, int subnoteId)
        {
            return _context.Subnotes.Where(s => s.NoteId == noteId && s.Id == subnoteId).FirstOrDefault();
        }

        public IEnumerable<Subnote> GetSubnotesForNote(int noteId)
        {
            return _context.Subnotes.Where(s => s.NoteId == noteId).ToList();
        }

        public void AddSubnoteForNote(int noteId, Subnote subnote)
        {
            var note = GetNote(noteId, false);
            note.Subnotes.Add(subnote);
        }
        
        public void DeleteSubnote(Subnote subnote)
        {
            _context.Subnotes.Remove(subnote);
        }

        public bool Save()
        {
            return (_context.SaveChanges() >= 0);
        }
    }
}