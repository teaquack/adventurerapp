using System.Diagnostics;
using Microsoft.Extensions.Logging;

namespace AdventurerApi.Services
{
    public class CloudMailService : IMailService
    {
        private string _mailFrom = Startup.Configuration["mailSettings:mailToAddress"];
        private string _mailTo = Startup.Configuration["mailSettings:mailFromAddress"];
        private ILogger<CloudMailService> _logger;

        public CloudMailService(ILogger<CloudMailService> logger)
        {
            _logger = logger;
        }

        public void Send(string subject, string message)
        {
            //send mail - output to debug window
            Debug.WriteLine($"Mail from {_mailFrom} to {_mailTo}, with CloudMailService.");
            Debug.WriteLine($"Subject: {subject}");
            Debug.WriteLine($"Message: {message}");
        }
    }
}
