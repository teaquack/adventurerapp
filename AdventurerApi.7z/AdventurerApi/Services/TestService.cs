using System;
using System.Linq;
using System.Reflection;

namespace AdventurerApi.Services
{
    public class TestService
    {        
        public void TestThings()
        {
            Type[] typelist = GetTypesInNamespace(Assembly.GetExecutingAssembly(), "AdventurerApi.Services");
            
            for (int i = 0; i < typelist.Length; i++)
            {
                Console.WriteLine(typelist[i].Name);
            }
        }
    
        private Type[] GetTypesInNamespace(Assembly assembly, string nameSpace)
        {
            return assembly.GetTypes().Where(t => String.Equals(t.Namespace, nameSpace, StringComparison.Ordinal)).ToArray();
        }
    }
}