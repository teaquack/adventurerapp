using System.Collections.Generic;
using System.Linq;
using AdventurerApi.Entities;

namespace AdventurerApi.Services
{
    public interface IAdventurerRepository
    {
        bool NoteExists(int noteId);
        IEnumerable<Note> GetNotes();
        Note GetNote(int noteId, bool includeSubnotes = false);
        IEnumerable<Subnote> GetSubnotesForNote(int noteId);
        Subnote GetSubnoteForNote(int noteId, int subnoteId);
        void AddSubnoteForNote(int noteId, Subnote subnote);
        void DeleteSubnote(Subnote subnote);
        bool Save();
    }
}