using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdventurerApi.Entities
{
    public class Subnote
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Subject { get; set; }

        [MaxLength(250)]        
        public string Body { get; set; }

        [ForeignKey("NoteId")]
        public Note Note { get; set; }
        public int NoteId { get; set; }
        
    }
}