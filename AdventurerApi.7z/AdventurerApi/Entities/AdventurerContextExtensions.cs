using System.Collections.Generic;
using System.Linq;
using AdventurerApi.Entities;

namespace AdventurerApi
{
    public static class AdventurerApiExtensions
    {
        public static void EnsureSeedDataForContext(this AdventurerContext context)
        {
            if (context.Notes.Any())
            {
                return;
            }

            // init seed data
            var notes = new List<Note>()
            {
                new Note()
                {
                    Subject = "Hello World",
                    Body = "Welcome to the world. Haha.",
                    Subnotes = new List<Subnote>()
                    {
                        new Subnote() {
                            Subject = "This Real World",
                            Body = "The best world in this world."
                        }
                    }
                },
                new Note()
                {
                    Subject = "Hello Again",
                    Body = "Hello hello kamichiwa aloha hi.",
                    Subnotes = new List<Subnote>()
                    {
                        new Subnote() {
                            Subject = "Muchi-muchi",
                            Body = "Allo"
                        }
                    }
                },
                new Note()
                {
                    Subject = "Testing",
                    Body = "The test has just begun."
                }
            };

            context.Notes.AddRange(notes);
            context.SaveChanges();            
        }
    }
}