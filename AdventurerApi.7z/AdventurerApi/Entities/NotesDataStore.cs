using System.Collections.Generic;
using AdventurerApi.Models;

namespace AdventurerApi
{
    public class NotesDataStore
    {
        public static NotesDataStore Current { get; } = new NotesDataStore();
        public List<NoteDto> Notes {get; set;}

        public NotesDataStore()
        {
            Notes = new List<NoteDto>()
            {
                new NoteDto()
                {
                    Id = 1,
                    Subject = "Hello World",
                    Body = "Welcome to the world. Haha.",
                    Subnotes = new List<SubnoteDto>()
                    {
                        new SubnoteDto() {
                            Id = 1,
                            Subject = "This Real World",
                            Body = "The best world in this world."
                        }
                    }
                },
                new NoteDto()
                {
                    Id = 2,
                    Subject = "Hello Again",
                    Body = "Hello hello kamichiwa aloha hi.",
                    Subnotes = new List<SubnoteDto>()
                    {
                        new SubnoteDto() {
                            Id = 2,
                            Subject = "Muchi-muchi",
                            Body = "Allo"
                        }
                    }
                },
                new NoteDto()
                {
                    Id = 3,
                    Subject = "Testing",
                    Body = "The test has just begun."
                }
            };
        }
    }
}