using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdventurerApi.Entities
{
    public class Note
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Subject { get; set; }

        [MaxLength(200)]
        public string Body { get; set; }
        public ICollection<Subnote> Subnotes { get; set; }
                = new List<Subnote>();
    }
}