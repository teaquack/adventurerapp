using Microsoft.EntityFrameworkCore;

namespace AdventurerApi.Entities
{
    public class AdventurerContext : DbContext
    {
        public AdventurerContext(DbContextOptions<AdventurerContext> options) : base(options)
        {
            // Database.EnsureCreated();
            Database.Migrate();
        }
        public DbSet<Note> Notes {get;set;}
        public DbSet<Subnote> Subnotes {get;set;}
        public DbSet<Character> Characters {get;set;}
        public DbSet<Skill> Skills {get;set;}
        public DbSet<CharacterSkills> CharacterSkills {get;set;}


        // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        // {
        //     optionsBuilder.UseSqlServer("connectionstring");
        //     base.OnConfiguring(optionsBuilder);
        // }
    }
}