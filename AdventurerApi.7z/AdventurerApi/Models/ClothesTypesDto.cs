using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class ClothesTypesDto
    {
        public int Id {get;set;}
        public string Type {get;set;}
    }
}