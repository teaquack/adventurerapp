using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdventurerApi.Models
{
    public class CharacterForCreationDto
    {
        [Required(ErrorMessage ="You should give your character a name.")]
        [MaxLength(50)]
        public string Name { get; set; }
    }
}