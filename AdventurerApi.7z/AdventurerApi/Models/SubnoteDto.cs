using System.Linq;
using System.Threading.Tasks;

namespace AdventurerApi.Models
{
    public class SubnoteDto
    {
        public int Id { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}