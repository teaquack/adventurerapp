using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public interface INoteRepository
    {
        IEnumerable<NoteDto> GetAll();
        NoteDto Find(int id);
        void Add(NoteDto item);
        void Remove(int id);
    }
    public class NoteRepository : INoteRepository
    {
        private List<NoteDto> _list;

        public NoteRepository()
        {
            _list = new List<NoteDto>();
        }

        public void Add(NoteDto item)
        {
            item.Id=(_list.Count+1);
            _list.Add(item);
        }

        public NoteDto Find(int id)
        {
            return _list.Find(n=>n.Id==id);
        }

        public IEnumerable<NoteDto> GetAll()
        {
            return _list.AsReadOnly();
        }

        public void Remove(int id)
        {
            _list.RemoveAll(n=>n.Id==id);
        }
    }
}