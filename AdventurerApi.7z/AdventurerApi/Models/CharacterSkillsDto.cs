using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class CharacterSkillsDto
    {
        public int Id {get;set;}
        public int CharacterId {get;set;}
        public int SkillId {get;set;}
        public int? SkillTypeId {get;set;}
        public int? Level {get;set;}
        public int? BookId {get;set;}
        public int NumberOfSkills {get
            {
                return Skills.Count;
            }
        }
        public ICollection<SkillDto> Skills {get; set;}
        = new List<SkillDto>();

    }
}