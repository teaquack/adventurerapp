using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class SkillTypeDto
    {
        public int Id {get;set;}
        public string Type {get;set;}

    }
}