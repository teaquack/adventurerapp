namespace AdventurerApi.Models
{
    public class NoteWithoutSubnotesDto
    {
        public int Id {get; set;}
        public string Subject {get; set;}
        public string Body {get; set;}
    }
}