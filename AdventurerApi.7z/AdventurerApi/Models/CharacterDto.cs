using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class CharacterDto
    {
        public int Id {get;set;}
        public string Name {get;set;}
        
    }
}