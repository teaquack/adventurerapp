using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class BookDto
    {
        public int Id {get;set;}
        public string Name {get;set;}
        public string Contents {get;set;}
    }
}