using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class NoteDto
    {
        public int Id {get;set;}
        public string Subject {get;set;}
        public string Body {get;set;}

        public int NumberOfSubnotes {get
            {
                return Subnotes.Count;
            }
        }

        public ICollection<SubnoteDto> Subnotes {get; set;}
        = new List<SubnoteDto>();
    }
}