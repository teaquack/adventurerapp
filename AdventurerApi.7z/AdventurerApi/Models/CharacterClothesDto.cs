using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class CharacterClothesDto
    {
        public int Id {get;set;}
        public int CharacterId {get;set;}
        public int ClothesId {get;set;}
        public int ClothesTypeId {get;set;}

    }
}