using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdventurerApi.Models
{
    public class SubnoteForUpdateDto
    {
        [Required(ErrorMessage ="You should provide a subject value.")]
        [MaxLength(50)]
        public string Subject { get; set; }

        [MaxLength(200)]
        public string Body { get; set; }
    }
}