using System.Collections.Generic;

namespace AdventurerApi.Models
{
    public class SkillDto
    {
        public int Id {get;set;}
        public string Name {get;set;}
        
    }
}